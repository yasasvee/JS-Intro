
function p2kwiet180672937032_frmHttp_preshow_seq0(eventobject,    neworientation){

frmHttpPreShow.call(this);

};


function p2kwiet180672937032_btnGetSettings_onClick_seq0(eventobject){

getCurrentIntegritySettings.call(this);

};


function p2kwiet180672937032_btnIntegSetting_onClick_seq0(eventobject){

frmInteg.show();
	
};


function p2kwiet180672937032_btnAddKey_onClick_seq0(eventobject){

addKeyVal.call(this);

};


function p2kwiet180672937032_btnRemoveKey_onClick_seq0(eventobject){

removeKeyVal.call(this);

};


function p2kwiet180672937032_btnClearKeys_onClick_seq0(eventobject){

clearAllKeyVals.call(this);

};


function p2kwiet180672937032_btnDisplayKeys_onClick_seq0(eventobject){

displayKeyValsList.call(this);

};


function p2kwiet180672937032_button186678331555733_onClick_seq0(eventobject){

setHTTPMethodPost.call(this);

};


function p2kwiet180672937032_button186678331555734_onClick_seq0(eventobject){

setHTTPMethodGet.call(this);

};


function p2kwiet180672937032_btnAsync2_onClick_seq0(eventobject){

asyncServiceCall.call(this,"true");

};


function p2kwiet180672937032_btnHttpAsync2_onClick_seq0(eventobject){

httpRequestSend.call(this,"true",    "true");

};


function p2kwiet180672937032_btnjson_onClick_seq0(eventobject){

setContentTypeJson.call(this);

};


function p2kwiet180672937032_btnnojson_onClick_seq0(eventobject){

restContentType.call(this);

};


function p2kwiet180672937032_btnAsync_onClick_seq0(eventobject){

asyncServiceCall.call(this,"false");

};


function p2kwiet180672937032_btnSync_onClick_seq0(eventobject){

syncServiceCall.call(this);

};


function p2kwiet180672937032_btnHttpSync_onClick_seq0(eventobject){

httpRequestSend.call(this,"false",    null);

};


function p2kwiet180672937032_btnHttpAsync_onClick_seq0(eventobject){

httpRequestSend.call(this,"true",    "false");

};


function p2kwiet180672937055_frmHttpPostParams_preshow_seq0(eventobject,    neworientation){

frmHttpPostParamsPreShow.call(this);

};


function p2kwiet180672937055_btnGetSettings_onClick_seq0(eventobject){

getCurrentIntegritySettingsPost.call(this);

};


function p2kwiet180672937055_btnIntegSetting_onClick_seq0(eventobject){

frmInteg.show();
	
};


function p2kwiet180672937055_btnJsonTable_onClick_seq0(eventobject){

setfrmHttpPostParamsContentType.call(this,"jsontable");

};


function p2kwiet180672937055_btnJsonString_onClick_seq0(eventobject){

setfrmHttpPostParamsContentType.call(this,"jsonstring");

};


function p2kwiet180672937055_btnFileUpload_onClick_seq0(eventobject){

setfrmHttpPostParamsContentType.call(this,"fileupload");

};


function p2kwiet180672937055_btnRawBytes_onClick_seq0(eventobject){

setfrmHttpPostParamsContentType.call(this,"rawbytes");

};


function p2kwiet180672937055_btnReset_onClick_seq0(eventobject){

setfrmHttpPostParamsContentType.call(this,null);

};


function p2kwiet180672937055_btnAsync_onClick_seq0(eventobject){

asyncServiceCallPostParams.call(this);

};


function p2kwiet180672937055_btnSync_onClick_seq0(eventobject){

syncServiceCallPostParams.call(this);

};


function p2kwiet180672937055_btnHttpSync_onClick_seq0(eventobject){

httpRequestSendPostParams.call(this,"false");

};


function p2kwiet180672937055_btnHttpAsync_onClick_seq0(eventobject){

httpRequestSendPostParams.call(this,"true");

};


function p2kwiet180672937060_button213792175820871_onClick_seq0(eventobject){

frmHttp.show();
	
};


function p2kwiet180672937060_button213792175820872_onClick_seq0(eventobject){

frmHttpPostParams.show();
	
};


function p2kwiet180672937088_frmInteg_preshow_seq0(eventobject,    neworientation){

preshowCB.call(this);

};


function p2kwiet180672937088_btn1_onClick_seq0(eventobject){

addDomain.call(this);

};


function p2kwiet180672937088_btn2_onClick_seq0(eventobject){

removeDomain.call(this);

};


function p2kwiet180672937088_btn3_onClick_seq0(eventobject){

clearAllDomains.call(this);

};


function p2kwiet180672937088_btn4_onClick_seq0(eventobject){

displayDomainsList.call(this);

};


function p2kwiet180672937088_btnAlgo_onClick_seq0(eventobject){

setAlgo.call(this);

};


function p2kwiet180672937088_btnSalt_onClick_seq0(eventobject){

setSalt.call(this);

};


function p2kwiet180672937088_btnHdr_onClick_seq0(eventobject){

setHdr.call(this);

};


function p2kwiet180672937088_btnValT_onClick_seq0(eventobject){

setvalidateRespTrue.call(this);

};


function p2kwiet180672937088_btnValF_onClick_seq0(eventobject){

setvalidateRespFalse.call(this);

};


function p2kwiet180672937088_btnSet_onClick_seq0(eventobject){

setIntegrityCheck.call(this);

};


function p2kwiet180672937088_btnRm_onClick_seq0(eventobject){

removeIntegrityCheck.call(this);

};


function p2kwiet180672937088_btnTestPage_onClick_seq0(eventobject){

frmHTTPTestPage.show();
	
};

