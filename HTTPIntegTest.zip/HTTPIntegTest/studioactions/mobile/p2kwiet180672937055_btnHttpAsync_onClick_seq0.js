function p2kwiet180672937055_btnHttpAsync_onClick_seq0(eventobject) {
    return httpRequestSendPostParams.call(this, "true");
}