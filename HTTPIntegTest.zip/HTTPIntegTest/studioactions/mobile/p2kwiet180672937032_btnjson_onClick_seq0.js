function p2kwiet180672937032_btnjson_onClick_seq0(eventobject) {
    return setContentTypeJson.call(this);
}