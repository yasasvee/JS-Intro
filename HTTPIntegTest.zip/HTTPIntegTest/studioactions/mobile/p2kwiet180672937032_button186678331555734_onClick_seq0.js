function p2kwiet180672937032_button186678331555734_onClick_seq0(eventobject) {
    return setHTTPMethodGet.call(this);
}