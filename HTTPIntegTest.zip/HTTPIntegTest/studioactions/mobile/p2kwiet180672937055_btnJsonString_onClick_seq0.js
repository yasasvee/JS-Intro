function p2kwiet180672937055_btnJsonString_onClick_seq0(eventobject) {
    return setfrmHttpPostParamsContentType.call(this, "jsonstring");
}