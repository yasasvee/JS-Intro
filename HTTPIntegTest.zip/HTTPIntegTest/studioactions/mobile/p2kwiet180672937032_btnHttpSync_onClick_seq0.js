function p2kwiet180672937032_btnHttpSync_onClick_seq0(eventobject) {
    return httpRequestSend.call(this, "false", null);
}