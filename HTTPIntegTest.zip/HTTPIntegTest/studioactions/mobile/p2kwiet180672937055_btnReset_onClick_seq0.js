function p2kwiet180672937055_btnReset_onClick_seq0(eventobject) {
    return setfrmHttpPostParamsContentType.call(this, null);
}