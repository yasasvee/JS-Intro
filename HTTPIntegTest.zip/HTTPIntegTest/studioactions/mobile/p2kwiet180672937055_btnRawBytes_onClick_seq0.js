function p2kwiet180672937055_btnRawBytes_onClick_seq0(eventobject) {
    return setfrmHttpPostParamsContentType.call(this, "rawbytes");
}