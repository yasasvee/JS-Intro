function p2kwiet180672937088_btnAlgo_onClick_seq0(eventobject) {
    return setAlgo.call(this);
}