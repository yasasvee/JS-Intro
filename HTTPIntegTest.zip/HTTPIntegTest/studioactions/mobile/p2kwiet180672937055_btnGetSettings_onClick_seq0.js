function p2kwiet180672937055_btnGetSettings_onClick_seq0(eventobject) {
    return getCurrentIntegritySettingsPost.call(this);
}