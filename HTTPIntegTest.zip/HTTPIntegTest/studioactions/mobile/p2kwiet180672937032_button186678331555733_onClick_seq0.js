function p2kwiet180672937032_button186678331555733_onClick_seq0(eventobject) {
    return setHTTPMethodPost.call(this);
}