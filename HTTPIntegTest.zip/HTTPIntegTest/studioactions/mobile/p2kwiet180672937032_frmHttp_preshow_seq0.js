function p2kwiet180672937032_frmHttp_preshow_seq0(eventobject, neworientation) {
    return frmHttpPreShow.call(this);
}