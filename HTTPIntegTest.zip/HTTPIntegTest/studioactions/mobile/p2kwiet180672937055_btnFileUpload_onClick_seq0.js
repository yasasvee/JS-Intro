function p2kwiet180672937055_btnFileUpload_onClick_seq0(eventobject) {
    return setfrmHttpPostParamsContentType.call(this, "fileupload");
}