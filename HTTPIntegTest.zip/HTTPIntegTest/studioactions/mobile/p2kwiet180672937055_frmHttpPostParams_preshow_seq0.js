function p2kwiet180672937055_frmHttpPostParams_preshow_seq0(eventobject, neworientation) {
    return frmHttpPostParamsPreShow.call(this);
}