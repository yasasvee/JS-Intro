function p2kwiet180672937055_btnSync_onClick_seq0(eventobject) {
    return syncServiceCallPostParams.call(this);
}