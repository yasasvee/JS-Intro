function p2kwiet180672937032_btnAsync2_onClick_seq0(eventobject) {
    return asyncServiceCall.call(this, "true");
}