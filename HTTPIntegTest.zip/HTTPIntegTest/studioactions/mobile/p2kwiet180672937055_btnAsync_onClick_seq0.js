function p2kwiet180672937055_btnAsync_onClick_seq0(eventobject) {
    return asyncServiceCallPostParams.call(this);
}