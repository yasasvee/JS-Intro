function p2kwiet180672937032_btnClearKeys_onClick_seq0(eventobject) {
    return clearAllKeyVals.call(this);
}