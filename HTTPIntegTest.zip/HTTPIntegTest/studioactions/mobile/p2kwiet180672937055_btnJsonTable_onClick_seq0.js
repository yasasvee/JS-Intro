function p2kwiet180672937055_btnJsonTable_onClick_seq0(eventobject) {
    return setfrmHttpPostParamsContentType.call(this, "jsontable");
}