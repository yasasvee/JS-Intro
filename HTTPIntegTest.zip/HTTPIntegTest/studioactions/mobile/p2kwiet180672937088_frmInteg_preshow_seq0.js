function p2kwiet180672937088_frmInteg_preshow_seq0(eventobject, neworientation) {
    return preshowCB.call(this);
}