function p2kwiet180672937088_btnValT_onClick_seq0(eventobject) {
    return setvalidateRespTrue.call(this);
}