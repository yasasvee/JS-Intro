function p2kwiet180672937032_btnGetSettings_onClick_seq0(eventobject) {
    return getCurrentIntegritySettings.call(this);
}