function p2kwiet180672937088_btn3_onClick_seq0(eventobject) {
    return clearAllDomains.call(this);
}