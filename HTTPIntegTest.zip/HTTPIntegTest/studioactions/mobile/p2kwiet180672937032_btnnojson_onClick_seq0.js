function p2kwiet180672937032_btnnojson_onClick_seq0(eventobject) {
    return restContentType.call(this);
}