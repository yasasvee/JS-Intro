function p2kwiet180672937088_btnHdr_onClick_seq0(eventobject) {
    return setHdr.call(this);
}