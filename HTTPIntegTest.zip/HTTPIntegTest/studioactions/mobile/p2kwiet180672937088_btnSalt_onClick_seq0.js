function p2kwiet180672937088_btnSalt_onClick_seq0(eventobject) {
    return setSalt.call(this);
}