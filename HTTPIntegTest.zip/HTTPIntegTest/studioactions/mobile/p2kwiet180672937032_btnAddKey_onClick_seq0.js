function p2kwiet180672937032_btnAddKey_onClick_seq0(eventobject) {
    return addKeyVal.call(this);
}