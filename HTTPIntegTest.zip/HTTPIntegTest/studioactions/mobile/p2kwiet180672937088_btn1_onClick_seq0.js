function p2kwiet180672937088_btn1_onClick_seq0(eventobject) {
    return addDomain.call(this);
}