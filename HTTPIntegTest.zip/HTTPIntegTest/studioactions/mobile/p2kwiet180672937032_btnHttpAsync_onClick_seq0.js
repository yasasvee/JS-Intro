function p2kwiet180672937032_btnHttpAsync_onClick_seq0(eventobject) {
    return httpRequestSend.call(this, "true", "false");
}