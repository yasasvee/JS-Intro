function p2kwiet180672937032_btnIntegSetting_onClick_seq0(eventobject) {
    frmInteg.show();
}